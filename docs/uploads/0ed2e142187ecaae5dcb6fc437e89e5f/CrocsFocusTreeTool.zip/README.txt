This is tool to generate focus trees based on diagram.net xml files
Enter path to input and ouput file (output file can be generated)
get your focus tree, use help to get more info on more complex commands

Do whatever you want in direct use
NO SOURCE CODE DECOMPILATION ALLOWED - it is literally an open repository
https://gitlab.com/crocomoth/crocs-focus-tree-tool

My only plea is to reference me and this tool in credits/authors if you have used it for your mod

Changelog
v1.0
Initial upload